package com.adrianpoplesanu.OnlineReservations3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineReservations3Application {

	public static void main(String[] args) {
		SpringApplication.run(OnlineReservations3Application.class, args);
	}

}
