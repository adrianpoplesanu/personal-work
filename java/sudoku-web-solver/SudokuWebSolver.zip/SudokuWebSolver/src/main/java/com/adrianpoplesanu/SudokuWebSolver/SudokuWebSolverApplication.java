package com.adrianpoplesanu.SudokuWebSolver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SudokuWebSolverApplication {

	public static void main(String[] args) {
		SpringApplication.run(SudokuWebSolverApplication.class, args);
	}

}
