package com.adrianpoplesanu.AnifScheduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnifSchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
