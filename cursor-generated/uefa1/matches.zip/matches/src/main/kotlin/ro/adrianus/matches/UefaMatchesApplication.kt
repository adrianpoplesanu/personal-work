package ro.adrianus.matches

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class UefaMatchesApplication

fun main(args: Array<String>) {
	runApplication<UefaMatchesApplication>(*args)
}
